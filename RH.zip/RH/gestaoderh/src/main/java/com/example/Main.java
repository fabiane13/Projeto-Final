package com.example;

public class Main {

    public static void main(String args[]){
        App.main(args);
    //App.main(args)
    }
}